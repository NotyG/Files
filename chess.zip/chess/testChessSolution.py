import chessSolution
from pybricks.parameters import Color
maze=[[-1,-1,-1,-1,-1, -1], #мнимый защитный край
      [-1, 0, 0, 0, 0, -1], #первый ряд
      [-1, 0, 0, 0, 0, -1], #второй ряд
      [-1, 0, 0, 0, 0, -1],
      [-1, 0, 0, 0, 0, -1], #4 ряд
      [-1,-1,-1,-1,-1, -1]]#мнимый защитный край

orderFigures=['blue', 'green', 'yellow', 'red']
positionFigures = ['green', 'blue', 'yellow', 'red']
solution = chessSolution.solve(orderFigures, positionFigures) #solution - список объектов Figure
# print(solution[0]._yStart, solution[0]._xStart)
for i in range(0, 4):
    maze[solution[i].y][solution[i].x] = solution[i].getType()
for i in range(0, 6):
    print(*maze[i])