#!/usr/bin/env pybricks-micropython
# -*- coding: utf-8 -*-
from copy import deepcopy
from sys import exit
import pathFinder
from miniStructures import Position
from Robot import Robot
from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import Port, Stop, Direction, Button, Color
# from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
# from pybricks.media.ev3dev import SoundFile, ImageFile
      #      |start|
      #         #
      #------->
maze=[[-1,-1,-1,-1,-1, -1], #мнимый защитный край
      [-1, 0, -2, -2, 'k', -1], #первый ряд
      [-1, 0, 0, 0, 0, -1], #второй ряд
      [-1, 0, 0, 's', 0, -1],
      [-1, 0, 0, 0, 0, -1], #4 ряд
      [-1,-1,-1,-1,-1, -1]]#мнимый защитный край

startPos = Position(1, 3)
endPos = Position(2, 3)
mazeUnfold = pathFinder.waveUnfolding(deepcopy(maze), startPos, endPos)
for i in range(6):
    print(*mazeUnfold[i])
path, mazeFold = pathFinder.findPath(deepcopy(maze), startPos,endPos)
print()
for i in range(len(mazeFold)):
      print(*mazeFold[i])
print()
for pos in path:
      print(pos.y, pos.x)