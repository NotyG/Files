#!/usr/bin/env pybricks-micropython
# -*- coding: utf-8 -*-
from miniStructures import Position
#from copy import deepcopy
def waveUnfolding(maze, startPos, endPos): #maze - поле, startPos - Position,
    wfront = 1
    maze[endPos.y][endPos.x] = 0
    # print(startPos.y, startPos.x)
    # print(endPos.y, endPos.x)
    maze[startPos.y][startPos.x] = 'c'
    #currentPositions = [startPos]
    currentPositions = []
    currentPositions.append(startPos)
    nextPositions = []
    while maze[endPos.y][endPos.x] == 0:
        for currentPos in currentPositions:
            for dY in range(-1, 2, 2):
                nextPositions.append(Position(currentPos.y + dY, currentPos.x))
            for dX in range(-1, 2, 2):
                nextPositions.append(Position(currentPos.y, currentPos.x + dX))
        #чтобы не менять список во время его перебора
        currentPositions = nextPositions.copy()  # нам не нужен указатель
        for nextPos in nextPositions:
            if nextPos.x > len(maze) or nextPos.y > len(maze):
                currentPositions.remove(nextPos)
                continue
            if maze[nextPos.y][nextPos.x] !=0:
                currentPositions.remove(nextPos)
            else:
                maze[nextPos.y][nextPos.x] = wfront
        nextPositions.clear()
        wfront += 1
    maze[startPos.y][startPos.x] = 0
    return maze #поле с развёрнутой волной

def waveFolding(maze, startPos, endPos):
    maze[startPos.y][startPos.x] = 0
    currentPos = Position(endPos.y, endPos.x)
    moves = [endPos]
    newPos = None
    while not (currentPos.y == startPos.y and currentPos.x == startPos.x):
        for d in range(-1, 2, 2):
            if type(maze[currentPos.y][currentPos.x + d]) == int:
                if maze[currentPos.y][currentPos.x] == maze[currentPos.y][currentPos.x + d] + 1:
                    newPos = Position(currentPos.y, currentPos.x + d)
                    break
            if type(maze[currentPos.y + d][currentPos.x]) == int:
                if maze[currentPos.y][currentPos.x] == maze[currentPos.y + d][currentPos.x] + 1:
                    newPos = Position(currentPos.y + d, currentPos.x)
                    break
        maze[currentPos.y][currentPos.x] = 'p' #для визуализации,
        if newPos == None: return -1
        currentPos = newPos #указатель
        moves.append(currentPos)
        #print(currentPos.y, currentPos.x)
    moves.reverse() #двигались с endPos до startPos
    #moves.pop(0) #нам не требуется координата начальной точки- уже требуется,
    # а ещё Robot.moveToNearPosition(endPos) может остаться в клетеке, если она стартовая и конечная
    return moves, maze

def findPath(maze, startPos, endPos):
    '''use deepcopy'''
    #print('in func')
    if( abs(endPos.x-startPos.x) == 1 and abs(endPos.y - startPos.y) == 0
    or abs(endPos.x-startPos.x) == 0 and abs(endPos.y - startPos.y) == 1):
        maze[endPos.y][endPos.x] = 'p'
        moves = [startPos, endPos]
        return moves, maze

    return waveFolding(waveUnfolding(maze, startPos, endPos), startPos, endPos)


